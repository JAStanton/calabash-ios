module Calabash
  module Cucumber

    # @!visibility public
    # The Calabash iOS gem version.
    VERSION = "0.21.1"

    # @!visibility public
    # The minimum required version of the Calabash embedded server.
    MIN_SERVER_VERSION = "0.21.1"
  end
end
